import React from 'react'
import { connect } from 'react-redux'
import { Field, reduxForm } from 'redux-form'
import { composeMessages } from '../actions'
import { getCookie } from '../utils/cookie';
// import Content from './Content'



class Compose extends React.Component {

  onFormSubmit = formValues => {
    const token = getCookie('token');
    this.props.composeMessages(token, formValues)
    // this.props.onFormSubmit(this.state.username, this.state.password)
  }

  renderError(meta) {
    if (meta.touched && meta.error) {
      return (
        <div className="ui error message">
          <div className="header">{meta.error}</div>
        </div>
      )
    }

  }

  renderInput = (formProps) => {
    const className = `field ${formProps.meta.error && formProps.meta.touched ? 'error' : ''}`
    return (
      <div className={className}>
        <label>{formProps.label}</label>
        <input type={formProps.type}
          placeholder={formProps.placeholder}
          value={formProps.input.value}
          onChange={formProps.input.onChange}
        ></input>
        <div className="header">{this.renderError(formProps.meta)}</div>
      </div>
    )
  }

  render () {
    return (
      <div>
        <div>
            <h1>Compose Message</h1>
        </div>
        <form className="ui form error" onSubmit={this.props.handleSubmit(this.onFormSubmit)}>
          <Field name="message_title" type='text' placeholder='Enter title' label="Title: " component={this.renderInput} />
          <Field name="message_content" type='text' placeholder='Enter message' label="Message: " component={this.renderInput} />
          <Field name="message_receiver" type='text' placeholder='Enter receiver' label="Receiver: " component={this.renderInput} />
          <button className="ui button primary" type="submit">Submit<i className="icon sign-in"></i></button>
        </form>
      </div>
    )
  }
}

const validate = (formValues) => {
  const errors = {}
  if (!formValues.message_title) {
    errors.message_title = 'Must Enter Message Title'
  }
  if (!formValues.message_content) {
    errors.message_content = 'Must Enter Message Content'
  }
  if (!formValues.message_receiver) {
    errors.message_receiver = 'Must Enter Receiver'
  }
  return errors
}

const mapStateToDispatch = dispatch => ({
  composeMessages: (token, formValues) => dispatch(composeMessages(token, formValues))
})

export default connect(null, mapStateToDispatch)(reduxForm({ form: 'compose', validate, touchOnChange: true })(Compose))