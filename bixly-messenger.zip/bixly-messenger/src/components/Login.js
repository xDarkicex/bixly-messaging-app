import React from 'react'
import { connect } from 'react-redux'
import { Field, reduxForm } from 'redux-form'
import { loginToMessages } from '../actions'
// import assets from here
import './Login.css'

class Login extends React.Component {
  onFormSubmit = formValues => {
    this.props.loginToMessages(formValues)
    // this.props.onFormSubmit(this.state.username, this.state.password)
  }
  renderError(meta) {
    if (meta.touched && meta.error) {
      return (
        <div className="ui error message">
          <div className="header">{meta.error}</div>
        </div>
      )
    }

  }
  renderInput = (formProps) => {
    const className = `field ${formProps.meta.error && formProps.meta.touched ? 'error' : ''}`
    return (
      <div className={className}>
        <label>{formProps.label}</label>
        <input type={formProps.type}
          placeholder={formProps.placeholder}
          value={formProps.input.value}
          onChange={formProps.input.onChange}
        ></input>
        <div className="header">{this.renderError(formProps.meta)}</div>
      </div>
    )
  }
  render() {
    return (
      <div className="login-display">
        <div className="search-bar ui segment">
          <div>
            <h1>LOGIN</h1>
          </div>
          <form className="ui form error" onSubmit={this.props.handleSubmit(this.onFormSubmit)}>
            <Field name="username" type='text' placeholder='Enter username' label="Username: " component={this.renderInput} />
            <Field name="password" type='password' placeholder='Enter password' label="Password: " component={this.renderInput} />
            <button className="ui button primary" type="submit">login <i className="icon sign-in"></i></button>
          </form>
          {/* <form className="ui form" onSubmit={this.onFormSubmit}> */}
          {/* <div className="field">
            <label>Username: </label>
            <input type="text"
              placeholder="Enter username"
              value={this.state.username}
              onChange={this.onUsernameChange}
            ></input>
          </div>
          <div className="field">
            <label>Password: </label>
            <input type="password"
              placeholder="Enter password"
              value={this.state.password}
              onChange={this.onPasswordChange}
            ></input>
          </div>
          <button className="ui button"type="submit">login <i className="icon sign-in"></i></button> */}
          {/* </form> */}
        </div>
      </div>
    )
  }

}
const validate = (formValues) => {
  const errors = {}
  if (!formValues.username) {
    errors.username = 'Must Enter Username'
  }
  if (!formValues.password) {
    errors.password = 'Must Enter Password'
  }
  return errors
}

const mapStateToDispatch = dispatch => ({
  loginToMessages: formValues => dispatch(loginToMessages(formValues))
})

export default connect(null, mapStateToDispatch)(reduxForm({ form: 'login', validate, touchOnChange: true })(Login))