import React, { Component } from 'react'
import { connect } from 'react-redux'
import messages from '../apis/messages'
import { setToken, getMessages,getSentMessages, onButtonClick } from '../actions'
import Login from './Login'
import { getCookie } from '../utils/cookie';
import Inbox from './Inbox'
import Compose from './Compose'
import SideBar from './SideBar'

import './Content.css'
import './SideBar.css'


class App extends Component {
  componentDidMount() {
    const token = getCookie('token');
    this.props.setToken(token);
    this.props.getMessages(token, this.props.menu.menuName) 
    this.props.getSentMessages(token, this.props.menu.menuName) 
  }


  onFormSubmit = async (username, password) => {
    await messages.post('api-token-auth/', {
        "username": username,
        "password": password
    }).then((res) => {
      if (res.status === 200) {
        this.setState({token: res.data.token})
      }
    })
  }
  renderContent = (name) => {
    console.log("%%%%%%%%", name.menuName)
    switch(name.menuName) {
      case 'compose/messages/':
        console.log('compose messages')
        return (
          <div className="pusher page-content">
            <Compose/>
          </div>
        )
      case 'messages/':
        console.log('case one')
        return (
          <div className="pusher page-content">
            <Inbox content={this.props.messages}/>    
          </div> 
        )
      case 'messages/sent':
          
          return (
            <div className="pusher page-content">
              <Inbox content={this.props.sentmessages}/>    
            </div> 
          )
      default: 
        return <div>No Messages</div>
    }
  }

  render() {
    // Check if user is logged in
    if (!this.props.token) {
      return (
        <div className="ui container" style={{height: '100vh', display: 'flex', alignItems: 'center'}}>
          <Login onFormSubmit={this.onFormSubmit}/>
        </div>
      )
    } 
    return (
    <div className="App-Container">
      <div className="ui sidebar thin inverted vertical labeled icon menu">
        <SideBar config={this.props}/>
      </div>
      <div className="ui basic icon top fixed menu">
        <button className="toggle item"><i className="sidebar icon"></i>Menu</button>
      </div>
      {this.renderContent(this.props.menu)}
    </div>
    )
  }

}

const mapStateToProps = state => ({ 
  token: state.login.token,
  messages: state.messages,
  sentmessages: state.sentmessages,
  buttons: [
    {name: 'compose', route: 'compose/messages/'},
    {name: 'inbox', route: 'messages/'}, 
    {name: 'sent', route: 'messages/sent'}],
  menu: state.menu

});

const mapDispatchToProps = dispatch => ({
  setToken: token => dispatch(setToken(token)),
  getMessages: (token, name) => dispatch(getMessages(token, name)),
  getSentMessages: (token, name) => dispatch(getSentMessages(token, name)),
  onButtonClick: name => dispatch(onButtonClick(name))
});

export default connect(mapStateToProps, mapDispatchToProps)(App)
