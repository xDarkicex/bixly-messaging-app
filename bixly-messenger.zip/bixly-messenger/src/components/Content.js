import React from 'react'
import { connect } from 'react-redux'
import { deleteMessage, detail_message } from '../actions'
import { getCookie } from '../utils/cookie';

class Content extends React.Component {

  deleteMessage(e, id) {
    const token = getCookie('token');
    this.props.deleteMessage(token, id);
  }

  detail_message(e, id) {
    const token = getCookie('token');
    this.props.detail_message(token, id);
  }

  render () {
    console.log("props value", this.props)
    console.log("states value", this.state)
    if(this.props.messages.messages.length) {
      return this.props.messages.messages.map(message => {
        return (
        <div key={Math.random() + message.id} className="ui container">
          <div className="ui segment col-10">
            <p onClick = {(e) => this.detail_message(e, message.id)}><span className="ui header">{message.sender}</span> {message.title}
            <button onClick={(e) => this.deleteMessage(e,  message.id)} className="btn btn-danger col-2">
              Remove
            </button>
            </p>
            
          </div>
          
        </div>
        
        )
      })
    }
    return <div>Nothing</div>
  }
}

const mapStateToProps = state => ({ 
  messages: state.messages,
});

const mapDispatchToProps = dispatch => ({
  deleteMessage: (token, id) => dispatch(deleteMessage(token, id)),
  detail_message: (token, id) => dispatch(detail_message(token, id))
});

export default connect(mapStateToProps, mapDispatchToProps)(Content)

