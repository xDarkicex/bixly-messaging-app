import React from 'react'


const SideBar = ({config}) => {
  console.log(config)
  return config.buttons.map((item) => {
    return (
      <div key={Math.random()} className="ui container">
         <div className="item buttons"  onClick={() => config.onButtonClick(item.route)}>{item.name}</div>
      </div>
    )
     
  })
}

export default SideBar