import React from 'react'
import Content from './Content'

const Inbox = (props) => {
  return (
    <div>
      <Content {...props.content}/>
    </div>
    )
}

export default Inbox