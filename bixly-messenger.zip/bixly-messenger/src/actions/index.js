import messages from '../apis/messages'
import { setCookie } from '../utils/cookie'

export const loginToMessages = formValues => {
  return async (dispatch) => {
    try {
      const res = await messages.post('api-token-auth/', {
        "username": formValues.username,
        "password": formValues.password
      })

      setCookie('token', res.data.token);
      dispatch(setToken(res.data.token));
    } catch (error) {
      console.log(" ==== token auth error ===", error);
      dispatch({ type: "SIGN_IN_FAILED" });
    }
  }
}

export const deleteMessage = (token, id) => {
  return async (dispatch) => {
    try {
      const res = await messages.delete(`messages/${id}`, {
        headers: {
          Authorization: `Token ${token}`,
        }
      })
      console.log("delete response data is ", res)
      if(res.data.data === 'success') {
        console.log("delete success")
        const res = await messages.get('messages/', {
          headers: {
              Authorization: `Token ${token}`
          }
        })
        dispatch({
          type: "DELETE_MESSAGES_SUCCEED",
          payload: res.data
        })
      }
    } catch (error) {
      console.log(" ==== token auth error ===", error);
      dispatch({ type: "DELETE_FAILED" });
    }
  }
}

export const detail_message = (token, id) => {
  return async (dispatch) => {
    try {
      const res = await messages.get(`messages/${id}`, {
        headers: {
          Authorization: `Token ${token}`,
        }
      })
      console.log("detail response data is ", res)
      if(res.status === '200') {
        console.log("detailed success")
        dispatch({
          type: "DETAIL_MESSAGES_SUCCEED",
          payload: res.data
        })
      }
    } catch (error) {
      console.log(" ==== token auth error ===", error);
      dispatch({ type: "DETAIL_FAILED" });
    }
  }
}

export const composeMessages = (token, formValues) => {
  return async (dispatch) => {
    try {

      var bodyFormData = new FormData();

      bodyFormData.set('title', formValues.message_title);
      bodyFormData.set('body', formValues.message_content);
      bodyFormData.set('receiver', formValues.message_receiver);
      const res = await messages.post('messages/', bodyFormData, {
        headers: {
          Authorization: `Token ${token}`,
        }
        })
        console.log("response data is ", res.data.data)
        if(res.data.data === 'success') {
          console.log("updated success")
          const res = await messages.get('messages/', {
            headers: {
                Authorization: `Token ${token}`
            }
          })
          dispatch({
            type: "COMPOSE_MESSAGES_SUCCEED",
            payload: res.data
          })
        }
    } catch (error) {
      console.log(" ==== token auth error ===", error);
      dispatch({ type: "COMPOSER_FAILED" });
    }
  }
}

export const getMessages = (token, name) => {
  return async (dispatch) => {
    try {
      const res = await messages.get(`${name}`, {
        headers: {
            Authorization: `Token ${token}`
          }
      })
      dispatch({
        type: "GET_MESSAGES_SUCCEED",
        payload: res.data
      })
    } catch (error) {
      console.log(" ==== Messages get error ===", error);
      dispatch({ type: "GET_MESSAGES_FAILED" });
    }
  }
  
}

export const getSentMessages = (token, name) => {
  return async (dispatch) => {
    try {
      const res = await messages.get(`${name}`, {
        headers: {
            Authorization: `Token ${token}`
          }
      })
      dispatch({
        type: "GET_SENTMESSAGES_SUCCEED",
        payload: res.data
      })
    } catch (error) {
      console.log(" ==== Messages get error ===", error);
      dispatch({ type: "GET_MESSAGES_FAILED" });
    }
  }
  
}

// export const getSentMessages = token => {
//   return async (dispatch) => {
//     try {
//       const res = await messages.get('messages/sent/', {
//         headers: {
//             Authorization: `Token ${token}`
//           }
//       })
//       dispatch({
//         type: "GET_SENT_MESSAGES_SUCCEED",
//         payload: res.data
//       })
//     } catch (error) {
//       console.log(" ==== Get SENT Messages get error ===", error);
//       dispatch({ type: "GET_SENT_MESSAGES_FAILED" });
//     }
//   }
// }

export const setToken = token => ({
  type: 'SIGN_IN',
  payload: token
});

export const goToPage = name => {
  return async (dispatch, name) => {
    dispatch({
      type: 'RENDER_INDEX',
      name
    })
  }
}

export const onButtonClick = name =>{
  return async (dispatch) => {
    dispatch({
      type: 'ON_BUTTON_CLICK',
      payload: name
    })
  }
}

