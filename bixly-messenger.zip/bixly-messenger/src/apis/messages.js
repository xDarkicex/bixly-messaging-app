import axios from 'axios'


export default axios.create({
  baseURL: 'https://messaging-test.bixly.com',
})