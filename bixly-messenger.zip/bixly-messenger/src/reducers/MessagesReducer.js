const INITIAL_STATE = {
  messages: [],
  sentmessages: [],
  name: ''
}

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case 'GET_MESSAGES_SUCCEED':
      return {
        ...state,
        messages: action.payload
      }
    case 'GET_SENTMESSAGES_SUCCEED':
        return {
          ...state,
          sentmessages: action.payload
        }
    case 'GET_SENT_MESSAGES_SUCCEED':
      return {
        ...state,
        messages: action.payload
      }
    case 'DELETE_MESSAGES_SUCCEED':
      return {
        ...state,
        messages: action.payload
      }
    case 'DETAIL_MESSAGES_SUCCEED':
      return {
        ...state,
        messages: action.payload
      }
    case 'COMPOSE_MESSAGES_SUCCEED':
      console.log("updated messages value", action.payload)
      return {
        ...state,
        messages: action.payload,
        menuName: 'messages/'
      }
    default: 
      return state
  }
}