import {combineReducers} from 'redux'
import {reducer as formReducer} from 'redux-form'
import LoginReducer from './LoginReducer'
import MesssagesReducer from './MessagesReducer'
import MenuReducer from './MenuReducer'

export default combineReducers({
  form: formReducer,
  login: LoginReducer,
  messages: MesssagesReducer,
  menu: MenuReducer
})

