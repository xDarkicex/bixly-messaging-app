const INITIAL_STATE = {
  menuName: 'messages/'
}

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case 'ON_BUTTON_CLICK':
      return {
        ...state,
        menuName: action.payload
      }
    case 'ON_COMPOSE_SUCCESS':
      return {
        ...state,
        menuName: action.payload
      }
    default: 
      return state
  }
}